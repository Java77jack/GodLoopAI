from loop_engine import run_god_loop

if __name__ == "__main__":
    run_god_loop()