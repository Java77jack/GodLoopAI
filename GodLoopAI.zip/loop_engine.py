import time
from device_manager import SmartLight, SmartCamera

def run_god_loop():
    light = SmartLight("Living Room")
    cam = SmartCamera("Front Door")

    while True:
        print("Running God Loop...")
        light.check_and_act()
        cam.check_and_act()
        time.sleep(5)